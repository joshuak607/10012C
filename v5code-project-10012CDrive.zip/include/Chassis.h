#pragma once
#include "vex.h"
#include "Sensors.h"
class Chassis{

    private:

    // ExpoDrive function: Joystick value, Exponent of Line, dead zone and minimun motor val
    int expoDrive(int joyVal, float driveExp, int joyDead, int motorMin);

    public:

    Sensors sensors;

    /*AUTONOMOUS FUNCTIONS*/
    
    // Strafe function
    void Strafe(float angle,float time);

    // Drive Functions
    void drive(float inches, unsigned int speed);
    void drivePID(float kP,float kI,float kD,float inches,unsigned int timeout);

    // TurnFunctions (/w inertial)
    void turnFor(float Degrees,unsigned int speed);
    void turnPID(float kP,float kI, float kD, float Degrees, unsigned int timeout);
    void swingTurn(bool isRight,float Degrees,unsigned int speed);
    void swingTurnPID(float kP,float kI, float kD,bool isRight, float Degrees, unsigned int timeout);

    // Align (/w sonars)
    void Align(unsigned int timeout);
    void Align(float distance,float LkP,float LkI,float LkD,float RkP,float RkI,float RkD,unsigned int timeout);
    void Align(float distance,unsigned int speed,unsigned int timeout);
    

    /*USER FUNCTIONS*/
    
    void Arcade(float xAxis,float yAxis);
    void Tank(float yAxisLeft, float yAxisRight);
    void Mechanum(float StrafeAxis,float TurnAxis,float yAxis);

    void stop();

}; // END class Chassis