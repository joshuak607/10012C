#pragma once

#include "vex.h"

class Sensors {

  private:
  
  // These are all fixes glitches in the vex inertial software
  float InertialManipulater = 0;
  void waitUntilCalibrated();
  float InertialFix(float);
  bool InertialValid();

  public:

  // Get the Inertial value with fix and value reset implimented
  float getInertial();
  // Get the left sonar value
  float getLSonar();
  // Get the right sonar value
  float getRSonar();
  // Calibrate the Inertial
  void calibrateInertial();
  // Set Inertial value
  void setInertial(float);

}; // END class Sensors
