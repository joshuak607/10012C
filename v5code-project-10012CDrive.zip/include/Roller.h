#pragma once
#include "vex.h"
class Roller {
  
  public:
  void spin(int);
  void rotateFor(unsigned int,int);
  void stop();

}; // END class Roller