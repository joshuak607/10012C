#include "Roller.h"

void Roller::spin(int speed) {
} // END void Intake::spin(int speed)

void Roller::rotateFor(unsigned int time,int speed) {
  spin(speed);
  task::sleep(time);
  stop();
} // END void Intake::rotateFor(unsigned int time,int speed)

void Roller::stop() {
} // END void Intake::stop()