#include "Sensors.h"

using namespace vex;

// Waits until the Inertial is calibrated
void Sensors::waitUntilCalibrated() {

  while(Inertial.isCalibrating()){
    task::sleep(10);
  } // END while(Inertial.isCalibrating())

} // END void Sensors::waitUntilCalibrated()

// Turns Inertial values like -10 into 350 or 370 into 10
float Sensors::InertialFix(float InertialVal) {

  // Too low
  while(InertialVal < 0) {
    InertialVal += 360;
  } // END while(InertialVal < 0)

  // Too high
  while(InertialVal > 360) {
    InertialVal -= 360;
  } // END while(InertialVal > 360)

  return InertialVal;

} // END float Sensors::InertialFix(float InertialVal)

// The vex Inertial is corrupted if it returns a value higher than 360 or lower than -360
bool Sensors::InertialValid() {

  if(Inertial.rotation(deg) < -360 || Inertial.rotation(deg) > 360) {
    return false;
  } // END if(Inertial.rotation(deg) < -360 || Inertial.rotation(deg) > 360)

  return true;

} // END bool Sensors::InertialValid()

void Sensors::calibrateInertial() {
  Inertial.startCalibration();
} // END void Sensors::calibrateInertial()

// Get the Inertial value with fix and value reset implimented
float Sensors::getInertial() {

  // Wait until the Inertial is calibrated
  waitUntilCalibrated();
  // If Inertial value isnt valid return -1

  if(!InertialValid()){
    return -1;
  } // END if(!InertialValid())

  // Retun fixed Inertial value of the Real Inertial value + the manipulator
  return InertialFix(Inertial.rotation(deg) + InertialManipulater);

} // END float Sensors::getInertial()

// Set Inertial value
void Sensors::setInertial(float InertialVal) {
  InertialManipulater = InertialFix(getInertial()+InertialVal);
} // END void Sensors::setInertial(float InertialVal)