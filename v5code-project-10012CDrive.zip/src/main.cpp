// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         12              
// FrontLeft            motor         13              
// BackLeft             motor         14              
// BackRight            motor         15              
// Controller1          controller                    
// Inertial             inertial      3               
// Flywheel             motor         19              
// Roller               motor         11              
// ---- END VEXCODE CONFIGURED DEVICES ----
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         12              
// FrontLeft            motor         13              
// BackLeft             motor         14              
// BackRight            motor         15              
// Controller1          controller                    
// Inertial             inertial      3               
// Flywheel             motor         2               
// Roller               motor         11              
// ---- END VEXCODE CONFIGURED DEVICES ----
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         12              
// FrontLeft            motor         13              
// BackLeft             motor         14              
// BackRight            motor         15              
// Controller1          controller                    
// Inertial             inertial      3               
// Flywheel             motor         2               
// Roller               motor         16              
// ---- END VEXCODE CONFIGURED DEVICES ----
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         12              
// FrontLeft            motor         13              
// BackLeft             motor         14              
// BackRight            motor         15              
// Controller1          controller                    
// Inertial             inertial      3               
// Flywheel             motor         2               
// Roller               motor         17              
// ---- END VEXCODE CONFIGURED DEVICES ----
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         12              
// FrontLeft            motor         13              
// BackLeft             motor         14              
// BackRight            motor         16              
// Controller1          controller                    
// Inertial             inertial      3               
// Flywheel             motor         2               
// Roller               motor         17              
// ---- END VEXCODE CONFIGURED DEVICES ----
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         12              
// FrontLeft            motor         13              
// BackLeft             motor         19              
// BackRight            motor         16              
// Controller1          controller                    
// Inertial             inertial      3               
// Flywheel             motor         2               
// Roller               motor         17              
// ---- END VEXCODE CONFIGURED DEVICES ----
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         12              
// FrontLeft            motor         10              
// BackLeft             motor         19              
// BackRight            motor         16              
// Controller1          controller                    
// Inertial             inertial      3               
// Flywheel             motor         2               
// Roller               motor         17              
// ---- END VEXCODE CONFIGURED DEVICES ----
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FrontRight           motor         9               
// FrontLeft            motor         10              
// BackLeft             motor         19              
// BackRight            motor         16              
// FourBarJosh          motor         6               
// Controller1          controller                    
// Inertial             inertial      3               
// Pnum                 digital_out   A               
// DSR                  distance      21              
// FourBarL             motor         2               
// FourBarR             motor         18              
// Controller2          controller                    
// DSL                  distance      12              
// MotorClamp           motor         17              
// InsideClamp          digital_out   H               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "Chassis.h"
#include "Roller.h"
#include "vex.h"
#include <vex_controller.h>

using namespace vex;

Chassis Drive;
class Roller Intakes;

// Amount of autos
const unsigned int autoSize = 3;
// Which auto
int autoSelector = 1;

// A global instance of competition
competition Competition;
 
 // Expo drive variables
int expoDrive(int joyVal, float driveExp, int joyDead, int motorMin) {

  // Define joySign
  int joySign;
  // Max value = 127 - accidental movement
  int joyMax = 127 - joyDead;
  // Joystick output
  int joyLive = abs(joyVal) - joyDead;
  // If joystick input > 0, drive forward
  if (joyVal > 0)
    joySign = 1;
  // If joystick input < 0, drive in reverse
  else if (joyVal < 0)
    joySign = -1;
  // If joystick input = 0, stop
  else
    joySign = 0;

  // Define power
  int power = joySign *
              (motorMin + ((127 - motorMin) * pow(joyLive, driveExp) /
                           pow(joyMax, driveExp))) * 2;
  // Run power function
  return power;
 
} // END int expoDrive(int joyVal, float driveExp, int joyDead, int motorMin)

// Tasks to be completed before competetion
void pre_auton(void) {

  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Reset brain screen
  Brain.Screen.clearScreen();

  // Reset brain timer
  Brain.Timer.reset();

  // Reset motor encoders
  FrontLeft.resetRotation();
  BackLeft.resetRotation();
  FrontRight.resetRotation();
  BackRight.resetRotation();
  Flywheel.resetRotation();
  Roller.resetRotation();

  // Reset motor positions
  FrontLeft.resetPosition();
  BackLeft.resetPosition();
  FrontRight.resetPosition();
  BackRight.resetPosition();
  Flywheel.resetPosition();
  Inertial.calibrate();
  Roller.resetPosition();

} // END voidpre_auton(void)

// Chooses auto
int selectAuto();

// Declare tasks
task AutoSelectTask(selectAuto);

// Autonomous code
void autonomous(void) {

  AutoSelectTask.stop();

  if (autoSelector == 1) { // AutoRightSide

  } 

  if (autoSelector == 2) { //AutoLeft

  }
    
  if (autoSelector == 3) { //Auto skills
  
  }
}
// END void autonomous(void)

// Opcontrol code
void drivercontrol(void) {
  while (1) {
    // Four Bar Control (Up)
    if(Controller1.ButtonR1.pressing()) {
      Roller.spin(fwd, 100, pct);
    } // END else if(Controller1.ButtonR1.pressing())

    // Four Bar Control (Down)
    else if(Controller1.ButtonR2.pressing()) {      
      Roller.spin(reverse, 100, pct);
    } // END else if(Controller1.ButtonR2.pressing())

    else if(Controller1.ButtonA.pressing()) {
      Flywheel.spin(reverse, 100, pct);
    }
    // END elseif(Controller.ButtonA.pressing())

    else {
      Flywheel.stop(brakeType::coast);
      Roller.stop(brakeType::hold);
    } // END else

    // Clear brain screen
    Brain.Screen.clearScreen();
    // Print values on brain screen
      Brain.Screen.printAt(1, 20, "Flywheel RPM: %f", Flywheel.velocity(velocityUnits::rpm));
    Brain.Screen.printAt(1, 80, "Roller: %f", Roller.velocity(velocityUnits::rpm));
    Brain.Screen.printAt(1, 140, "Inertial Rotation: %f",Inertial.rotation(rotationUnits::deg));
    Brain.Screen.render(); 

    // Wait 20 msec to allow brain screen to resetg===
    wait(20, msec);

    Drive.Arcade(Controller1.Axis3.value(), Controller1.Axis1.value());

  } // END while (1)

}// END void usercontrol(void)

// Main will set up the competition functions and callbacks.
int main() {

  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(drivercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {

    // Wait 100 msec to avoid wasted resources
    wait(100, msec);

  } // END while (true)

} // END in main()

int selectAuto() {

  Controller1.Screen.setCursor(2, 1);
  switch (autoSelector) {
 case 1:
      Controller1.Screen.print("Good Luck Ethan");
      break;
    case 2:
    Controller1.Screen.print("");
    break;
    case 3:
    Controller1.Screen.print("");
    break;
    case 4: 
    Controller1.Screen.print("");
    break;
  default:
    Controller1.Screen.print("ERR: Invalid case argument");
    break;
  } // END switch(autoSelector)

  while (1) {

    // wait until left or right button is pressing
    while (!(Controller1.ButtonLeft.pressing() ||
             Controller1.ButtonRight.pressing())) {
      task::sleep(100);
    } // END while(!(Controller2.ButtonLeft.pressing() ||
      // Controller2.ButtonRight.pressing()))

    // prep screen
    Controller1.Screen.setCursor(2, 1);

    // if button left is pressing, decrease autoselector by one
    if (Controller1.ButtonLeft.pressing()) {
      autoSelector = autoSelector <= 1 ? autoSize : autoSelector - 1;
      Controller1.Screen.clearLine(2);
    } // END if(Controller2.ButtonLeft.pressing())

    // if button right is pressing, increase autoselector by one
    if (Controller1.ButtonRight.pressing()) {
      autoSelector = autoSelector >= autoSize ? 1 : autoSelector + 1;
      Controller1.Screen.clearLine(2);
    } // END if(Controller2.ButtonRight.pressing())

    // print message depending on autoselector
    switch (autoSelector) {
    case 1:
      Controller1.Screen.print("Good Luck Ethan");
      break;
    case 2:
    Controller1.Screen.print("");
    break;
    case 3:
    Controller1.Screen.print("");
    break;
    case 4: 
    Controller1.Screen.print("");
    break;
    case 5: 
    default:
    Controller1.Screen.print("ERR: Invalid case argument");
      break;
    } // END switch(autoSelector)

    while (Controller1.ButtonLeft.pressing() ||
           Controller1.ButtonRight.pressing()) {
      task::sleep(100);
    } // END while(Controller2.ButtonLeft.pressing() ||
      // Controller2.ButtonRight.pressing())

  } // END while(1)

} // END int selectAuto()
