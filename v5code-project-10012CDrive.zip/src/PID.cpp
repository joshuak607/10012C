#include "PID.h"
PID::PID(float kP,float kI,float kD) {
  this->kP = kP;
  this->kI = kI;
  this->kD = kD;
} // END PID::PID(float kP,float kI,float kD)

float const PID::GetValue(float err) {
  D = err-P;
  I = (I + err) * kI < ILim ? I : I + err;
  P = err;
  return((P * kP)+(I * kI)+(D*kD));
} // END float const PID::GetValue(float err)

void PID::printFirstTime(unsigned int in) {

  if(time == 0) {
    time = in;
    Controller1.Screen.clearLine(2);
    Controller1.Screen.setCursor(2,0);
    Controller1.Screen.print("time: %d",time);
  } // END if(time == 0)

} // END void PID::printFirstTime(unsigned int in)